package pe.edu.unsch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Evaluacion360G111Application {

	public static void main(String[] args) {
		SpringApplication.run(Evaluacion360G111Application.class, args);
	}

}
